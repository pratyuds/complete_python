# -*- coding: utf-8 -*-
"""
Created on Sun Jan 30 16:06:03 2022

@author: praty
"""
import random
class Dice:
    def roll(self):
        first = random.randint(1,6)
        second = random.randint(1,6)
        return (first,second)
        