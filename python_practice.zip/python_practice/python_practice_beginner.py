# -*- coding: utf-8 -*-
"""
Created on Sat Jan 22 20:36:37 2022

@author: praty
"""
print("Hi Pratyusha")

name = "Chahit"
age = "6"
print('Hi ' + name+ " and my age is "+age+" years")

name = input("What is your name?  ")
print("Hi " +name)

name = input("what is your name? ")
color = input("what is your favorite colour? ")
print(name +" likes " +color)

## Datatypes with input
birth_year = input('Birth year:  ')
age = 2022 - int(birth_year)
print(age)

weight_lbs = input("weight in lbs:  ")
weight_kg = float(weight_lbs) * 0.45
print(weight_kg)

## Strings
course  = "python's course for beginners"
print(course)

course = 'python course for "beginners"'
print(course)

course = '''this is pratyusha
my son name is chahit
my mother name is maruthi
'''
print(course)

course = 'python is for beginners'
print(course[0])
print(course[-1])
print(course[-2])
print(course[0:3])
print(course[1:])
print(course[:5])
another= course[:]
print(another)

name = 'pratyusha'
print(name[1:-1])

### Formated strings

first = 'jhon'
last = 'smith'
message = first + ' [ ' + last + ' ] is a coder' # this is bit much harder that's why we used formated strings
print(message)
msg = f'{first} [ {last} ] is a coder' # this is formated strings
print(msg)

### string methods [these all are case sensitive methods]

course = 'python for beginners'
print(len(course))
print(course.upper())
print(course)
print(course.lower())
print(course.find('o'))
print(course.replace('beginners','absolute beginners'))
print(course.split(' '))
print('python' in course) # in operator for searching a string or character in a given string


### Arthemetic operators
print(10+3)
print(10-3)
print(10*3)
print(10/3)
print(10%3)
print(10**3)  # exponentiation

## argumented  opearators
x =10
x = x+3
print(x)
x += 3
print(x)
x -= 3
print(x)

### Operator precedence
x = 10+3*2 # * is having higher precedencr
print(x)
## order of precidence 
# 0) peranthesis
# 1) exponentiation
# 2) multiplication  or division
# 3) addition or subtraction
print(10+3-2*2**2)
print((10+3)*2**2)

## math functions
x = 2.7
print(round(x))
print(abs(-x))


import math

print(math.ceil(2.9))
print(math.floor(2.9))

### IF statements
is_hot = False
is_cold = True
if is_hot:
    print("it's a hot day")
    print('drink plenty of water')
elif is_cold:
    print('it is cold day')
    print('wear warm cloths')
else:
    print('enjoy your lovely day')
    
price  =1000000
good_credit =  False
if good_credit:
    down_payment = 0.1 * price
else:
    down_payment =0.2 * price
print(f" down_payment: ${down_payment}")

## Logical Operators
has_hight_income = True
has_good_credit =True
if has_hight_income and has_good_credit:
    print('Eligible for loan')
has_hight_income = True
has_good_credit =False
if has_hight_income or has_good_credit:
    print("eligible for loan")

## AND : both conditions to be true
## OR : at least one condition is true
##Not: if any boolean value may come it converts negative

has_creminal_record = False
has_good_credit =True

if has_good_credit and not has_creminal_record:
    print("eligible for loan")


## comparision operators
temparature = 29
if temparature>30:
    print("it's a hotday")
elif temparature <10:
    print("it's a cold day")
else:
    print("it's neither hot nor cold")
    
#name = "pr"
name = "pratyushachahitmaruthikumarinaveenkumarmathsdatasciencemachinelearningdeeplearningnaturallanguageprocessing"
#name = "pratyushachahit"
if len(name) <3:
    print("name must be atleast 3 characters")
elif len(name)>50:
    print("name can be maximum of 50 characters")
else:
    print("name looks good!")
    

## Weight Converter
weight = int(input("weight:  "))
unit = input('(L)bs or (K)g: ')
if unit.upper() =="L":
    converter = weight *0.45
    print(f"you are {converter} kiolos")
else:
    converter = weight/0.45
    print(f"you are {converter} pounds")
    
    
### While loops
i=1
while i<=5:
    print(i)
    i=i+1
print("Done")
## print * in a triangle
i=1
while i<=5:
    print('*'*i)
    i=i+1
print("done")

### gussing game
secret_number = 9
guess_count =0
guess_limit =3
while guess_count < guess_limit:
    guess  = int(input("Guess: "))
    guess_count +=1
    if guess == secret_number:
        print("you are win!")
        break
else:
    print("Sorry, you failed!")


##car game
command =""
while True:
   command =  input("> ").lower()
   if command == "start":
       print("car started ....")
   elif command == "stop":
       print("car stopped..")
   elif command == "help":
       print("""
start - to start the car
stop - to stop the car
quit - to quit
             """)
   elif command == "quit":
       break
   else:
        print("Sorry, I don't understand that!")
        
        
#advanced contions in car game
command =""
started = False
while True:
   command =  input("> ").lower()
   if command == "start":
       if started:
           print("car is already started")
       else:
           started = True
           print("car started ....")
   elif command == "stop":
       if not started:
           print(not started)
           print("car already stopped")
       else:
           started = False
           print("car stopped..")
   elif command == "help":
       print("""
start - to start the car
stop - to stop the car
quit - to quit
             """)
   elif command == "quit":
       break
   else:
        print("Sorry, I don't understand that!")
    
#### For loops
for item in'python':
    print(item)
for item in ['pratyusha','chahit','naveen','maruthi']:
    print(item)
for item in [1,2,3,4]:
    print(item)
    
for item in range(10):
    print(item)
for item in range(3,10):
    print(item)
for item in range(1,10,3):
    print(item)
    
prices = [10,20,30]
total =0
for item in prices:
    total += item
print(f"Total: {total}")

## nested loops
for x in range(4):
    for y in range(3):
        print(f"({x}, {y})")

numbers = [5,2,5,2,2]       
for x in numbers:
    output = ''
    for count in range(x):
        output +='x'
    print(output)
        
numbers = [5,1,5,1,5]       
for x in numbers:
    output = ''
    for count in range(x):
        output +='x'
    print(output)
    
### Lists
names= ['Naveen','Chahit','Maruthi',"pratyusha"]
print(names[0])
print(names)
print(names[:-2])
print(names[-1])
print(names[2:])
print(names[1:3])
names[0]="Naveen Kumar"
print(names)


numbers = [1,2,3,10,5,7,4]
print(max(numbers))### this is one type
max_number = numbers[0]
for item in numbers:
    if item >max_number:
        max_number = item
print(max_number)

## 2D list

matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
    ]
print(matrix[0][1])
for row in matrix:
    for col in row:
        print(col)

## list methods
numbers = [5,2,1,7,4]
numbers.append(20) ## it will add end of the list
print(numbers)
numbers.insert(3,22) ## it will append the specific position 3 is index position, 22 is vaule
print(numbers)
numbers.remove(1)# it's remove specific value
print(numbers)
numbers.clear()# it is remove entire list at a time
print(numbers)
numbers.pop() # it's remove the last item
print(numbers)
print(numbers.index(1)) # it's given the specific number position
print(50 in numbers) # it is given the specific values existed or not through boolean
print(5 in numbers)
numbers = [5,6,2,1,7,6,4]
print(numbers.count(6)) # it gives the count of specific value
numbers.sort() # it givies the assending order
numbers.reverse() #it gives the decending order
print(numbers)
numbers2 = numbers.copy()
numbers.append(10)
print(numbers)
print(numbers2)
# remove duplicates
uniques =[]
for item in numbers:
    if item not in  uniques:
        uniques.append(item)      
print(uniques)

## tuples
numbers = (1,2,3)

print(numbers[0])

## unpacking
# it is nothing but unpack the values in list or tuple we can assaign with variavbles and 
#we can perform any type of operations
numbers = (1,2,3)
val = [4,5,6]
x,y,z = numbers
a,b,c = val
print(x,y,z)
print(x*y*z)
print(x+y+z)
print(a,b,c)
print(a*b*c)
print(a+b+c)

## Dictionaries
customer = {
    "name":"pratyusha",
    "age":30,
    "is_verified":True
    }
print(customer["name"])
#this one dynamic calling
print(customer.get("birthdate")) # int his senariyo if key is not there it retruns None with out error
print(customer.get("birthdate","Jan 28 1991"))# if key value is not there we can set default value like this
customer['name']="Chahit"
print(customer['birthdate'])
customer['birthdate']="Jan 11 2017"
print(customer['birthdate'])

#
phone = input("phone: ")
digit_mapping = {
    "1":"one",
    "2":"two",
    "3":"three",
    "4":"four"
    }
output =""
for item in phone:
    output += digit_mapping.get(item,"!")+""
print(output)
phone = ["one","two","three","four","five"]
digit = {
    "one":1,
    "two":2,
    "three":3,
    "four":4,
    "five":5,
    "six":6
    }
out = []
for item in phone:
    out.append( digit.get(item,"#"))
print(out)

## Emoji converter
inp = input("> ")
words = inp.split()
emoji ={
        ":)":"😃",
        ":(":"😞"
            
        }
out =""
for word in words:
    out += emoji.get(word,word)+" "
print(out)

### functions

def get_user():
    print("Hi There!")
    print("welcome aboard")

print("start")
get_user()
print("finish")

##perameters
def get_user(name):
    print(f"Hi {name}!")
    print("welcome onboard")

print("start")
get_user("Pratyusha")
print("finish")

## passing multipke arguments thorigh  single perameters
def get_user(name):
    print(f"Hi {name}!")
    print("welcome onboard")

print("start")
get_user("Pratyusha")
get_user("Chahit")
print("finish")
## passing multiple perameters
def get_user(first_name,last_name):
    print(f"Hi {first_name} {last_name}!")
    print("welcome onboard")

print("start")
get_user("Pratyusha","Ghanta")
print("finish")

### keyword arguments
def get_user(first_name,last_name):
    print(f"Hi {first_name} {last_name}!")
    print("welcome onboard")

print("start")
get_user(last_name="Ghanta",first_name="Pratyusha")#here fistname and lastname or keyword arguments
#it is very use full in numerical computations
print("finish")

## one more example for numerical values of keyword arguments
def get_values(total_cost,shipping_cost,discount):
    print(f"Hi, the product of total_cost is {total_cost} and shipping_cost is {shipping_cost} and discount is {discount}")
    print("welcome onboard")

print("start")
get_values(discount=0.1,total_cost=100,shipping_cost=10)#here fistname and lastname or keyword arguments
#it is very use full in numerical computations
print("finish")

## Return statement
def square(number):
    return number*number
print(square(3))

# if we skip return stmt It returns function value along with None
def square(number):
    print(number*number)
    
print(square(3))

## creating a reusable Function
def emoji_converter(message):
    words = message.split()
    emoji ={
            ":)":"😃",
            ":(":"😞"
                
            }
    out =""
    for word in words:
        out += emoji.get(word,word)+" "
    
    return out

message = input("> ")
print(emoji_converter(message))

### Exceptions

age = int(input("> "))   
print(age)

# if we are passing like "abc" it is giving error like below
#ValueError: invalid literal for int() with base 10: 'abc'
# using exceptions we can these such type of errors
# for this type of error we can use try, catch
try:
    age = int(input("age: "))
    print(age)
except ValueError:
    print("pass interger value must")
    
## multiple exceptions
try:
    age =int(input("age: "))
    income = 20000
    risk = income/age
    print(age)
    print(risk)
except ZeroDivisionError:
    print("age cannnot be 0.")
except ValueError:
    print("Invalid value")
    
##try, except,else,finally
try:
    age=int(input("age: "))
    income =20000
    risk =income/age
    print(age)
    print(risk)
except ZeroDivisionError:
    print("age cannnot be 0.")
except ValueError:
    print("Invalid value")
else:
    print("nothing went wrong")
finally:
   
    print("try -except finished")
    
    
#### CLASSES
class  Point:
    def move(self):
        print("Move")
    def draw(self):
        print("Draw")
# here we can call it as function like point()     
point1 = Point()
#here we can call the functions inside class
point1.move()
point1.draw()
# we can define variables using that particalar object
point1.x =10
point1.y =30
print(point1.x,point1.y)


point2 = Point()
# if we can print variables it is through the attribute error
# point2 is completly different from point1
point2.x = 1
print(point2.x)
# main key keypints in classes
"""
--->we can use classes to define new types
like:   class Point:
---> these types can have methods that we define in the body of the class they can also
like :      def move(self):
                 print("Move")
---> and these methods have attributes that we can set any where in our programs .like
                point1 = Point()
                point1.x =10
                
                point2 = Point()
                point2.x = 100
"""   
## Constructors
class  Point:
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def move(self):
        print("Move")
    def draw(self):
        print("Draw")
# here we can call it as function like point()     
point1 = Point(10,20)
print(point1.y)
#here we can directly assaign the values to variables
point1.y =100
print(point1.x)
print(point1.y)


class  Point:
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def move(self):
        print("Move")
    def draw(self):
        print("Draw")
# here we can call it as function like point()     
point1 = Point(y=10,x=20)
print(point1.y)
#here we can directly assaign the values to variables
point1.y =100
print(point1.x)
print(point1.y)

##practice excersise -- I want to print name attribute, talk() method using class
class Person:
    def __init__(self,name):
        self.name = name
    def talk(self):
        print(f"Hi I am {self.name}")
        
pratyusha =Person("chahit")
print(pratyusha.name)
pratyusha.talk()
pratyusha.name = "Naveen"
print(pratyusha.name)
pratyusha.talk()

chahit = Person("Pratyusha")  
print(chahit.name)
chahit.talk()
chahit.name = "Maruthi"
print(chahit.name)
chahit.talk()

## Inheritence
class Mammal:
    def walk(self):
        print("walk")
        
class Dog(Mammal):
    pass
class Cat(Mammal):
    pass

dog1 = Dog()
dog1.walk()
cat1 = Cat()
cat1.walk()

# here we can take the methods and attributes from parent class along with
# we can define new methods and attributes in child classes also
# inherit means extract methods and attributes from parent class
class Mammal:
    def walk(self):
        print("walk")
        
class Dog(Mammal):
    def bark(self):
        print("Barking")
class Cat(Mammal):
    def be_annoying(self):
        print("annoying")

dog1 = Dog()
dog1.walk()
cat1 = Cat()
cat1.walk()
dog1.bark()
cat1.be_annoying()

### Modules #firsttype
from python_practice import converter
print(converter.Kg_to_lbs(79))
print(converter.Lbs_to_kg(76))
#second type - directly we can call functions from that file also
from python_practice.converter import Kg_to_lbs

Kg_to_lbs(79)

from python_practice.converter import Lbs_to_kg

Lbs_to_kg(76)


#practice for module
from python_practice.utils import find_max
number = [2,5,1,10,7,20]
print(find_max(number))

#or
from python_practice.utils import find_max
number = [2,5,1,10,7,20]
maximum = find_max(number)
print(maximum)

#Packages
#package is nothing but - creating a directory or folder in a specific project import that package.
from python_practice.utils import find_max
# from above python_practice is an package
#utils is an module.
#find_max is an function or method
# we can do like above or below
from python_practice import utils
number = [2,5,1,10,7,20]
print(utils.find_max(number))

## Generating Random values
# random is an in-built package
import random

for i in range(3):
    print(random.random()) # thia random.random gevies the random values inbetween 0 and 1
    
# generate integer numbers with in a particular range
import random
for i in range(3):
    print(random.randint(10,20))
    
#here, random.choice selects a random member from given list
import random
members = ['pratyusha','chahit','naveen','maruthi']

leader = random.choice(members)
    
print(leader)

#excersise - dice values always inbetween 1, 6
import random
from python_practice.dice import Dice
dice =Dice()
print(dice.roll())


### Files and Directories
from pathlib import Path

#absolute path -- complepath path means from root to current directory
#relative path -- it give current directory

path = Path("ecommerce")
print(path.exists())

path = Path("python_practice")
print(path.exists())

path = Path("emails")
print(path.mkdir())
print(path.exists())

print(path.rmdir())
print(path.exists())

path = Path("")
for file in path.glob("*.*"):
    print(file)

path = Path("python_practice")  
for file in path.glob("*.py"):
    print(file)

path = Path("")
for file in path.glob("*"):
    print(file)
    
### Pypi and pip
# pip using to install the required packages Pypi.org
#openpyxl package is used for reading /writing the excel files

### Excel spread sheets
## I was created transaction excel sheet and saved it in as same directory
import openpyxl as xl
wb = xl.load_workbook('python_practice/transactions.xlsx')
sheet = wb['Sheet1']
cell = sheet['a1']
cell = sheet.cell(1,1)
print(cell.value)
print(sheet.max_row)

for row in range(1,sheet.max_row +1):
    print(row)

for row in range(2,sheet.max_row +1):
    cell = sheet.cell(row,3)
    #print(cell.value)
    corrected_price =cell.value *0.9
    corrected_price_cell = sheet.cell(row,4)
    corrected_price_cell.value = corrected_price
    print(corrected_price_cell.value)
#wb.save('python_practice/transactions2.xlsx')

from openpyxl.chart import BarChart,Reference

values = Reference(sheet,
          min_row =2,
          max_row=sheet.max_row,
          min_col =4,
          max_col =4)
chart = BarChart()
chart.add_data(values)
sheet.add_chart(chart,'e2')

wb.save('python_practice/transactions2.xlsx')

## best practice in a software developer way
import openpyxl as xl
from openpyxl.chart import BarChart,Reference

wb = xl.load_workbook('python_practice/transactions.xlsx')
sheet = wb['Sheet1']

for row in range(2,sheet.max_row +1):
    cell = sheet.cell(row,3)
    #print(cell.value)
    corrected_price =cell.value *0.9
    corrected_price_cell = sheet.cell(row,4)
    corrected_price_cell.value = corrected_price
    print(corrected_price_cell.value)
    
values = Reference(sheet,
          min_row =2,
          max_row=sheet.max_row,
          min_col =4,
          max_col =4)
chart = BarChart()
chart.add_data(values)
sheet.add_chart(chart,'e2')

wb.save('python_practice/transactions2.xlsx')

# using functions with proper structure
def process_workbook(filename):
    wb = xl.load_workbook(filename)
    sheet = wb['Sheet1']
    
    for row in range(2,sheet.max_row +1):
        cell = sheet.cell(row,3)
        #print(cell.value)
        corrected_price =cell.value *0.9
        corrected_price_cell = sheet.cell(row,4)
        corrected_price_cell.value = corrected_price
        print(corrected_price_cell.value)
        
    values = Reference(sheet,
              min_row =2,
              max_row=sheet.max_row,
              min_col =4,
              max_col =4)
    chart = BarChart()
    chart.add_data(values)
    sheet.add_chart(chart,'e2')
    
    wb.save(filename)
    
process_workbook('python_practice/transactions.xlsx')


## what is machine learning

## Django frame work
# pip install django
#django-admin startproject pyshop .
