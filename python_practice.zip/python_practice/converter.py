# -*- coding: utf-8 -*-
"""
Created on Sun Jan 30 08:34:49 2022

@author: praty
"""

def Lbs_to_kg(weight):
    return weight * 0.45

def Kg_to_lbs(weight):
    return weight / 0.45