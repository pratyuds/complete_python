# -*- coding: utf-8 -*-
"""
Created on Mon Feb  7 07:25:31 2022

@author: praty
"""

### intermediate LEvel
## Optional perameters
def func(x):
    return x**2
call =func(5)
print(call)

def func(x=2):  ## here, 2 is the optional perameter
    return x**2
call =func(5)
print(call)

def func(x=2):
    return x**2
call =func()
print(call)

# optional with multiple perameters
def func(word,freq):
    print(word*freq)
call = func('chahit',5)

def func(word,freq =2): ## word is the base perameter, freq is optional peramenter
    print(word*freq)
call= func('chahit',5)

def func(word,freq =2):
    print(word*freq)
call= func('chahit')

def func(word,add=5,freq=2): 
## here, we can define based on our own choice like add, freq we can put optional perameters or any one perameter we can put optional.
    print(word*(add+freq))
call = func('chahit',2,4)

def func(word,add=5,freq=2):
    print(word*(add+freq))
call = func('chahit',0,2)

# with better example using car use case
class car(object):
    def __init__(self,make,model,year,condition,kms):
        self.make =make
        self.model = model
        self.year = year
        self.condition = condition
        self.kms = kms
    
    def display(self,showAll):
        if showAll:
            print("This car is a %s %s from %s,it is %s and has %s kms" %(self.make,self.model,self.year,self.condition,self.kms))
        else:
            print("This car is a %s %s from %s" %(self.make,self.model,self.year))
            
whip = car('Ford',"Fusion",2022,'New', 0)
whip.display(True)

class car(object):
    def __init__(self,make,model,year,condition='New',kms=0):
        self.make =make
        self.model = model
        self.year = year
        self.condition = condition
        self.kms = kms
    
    def display(self,showAll=True):
        if showAll:
            print("This car is a %s %s from %s,it is %s and has %s kms" %(self.make,self.model,self.year,self.condition,self.kms))
        else:
            print("This car is a %s %s from %s" %(self.make,self.model,self.year))
            
whip = car('Ford',"Fusion",2022,'New',10)
whip.display(True)

class car(object):
    def __init__(self,make,model,year,condition='New',kms=0):
        self.make =make
        self.model = model
        self.year = year
        self.condition = condition
        self.kms = kms
    
    def display(self,showAll=True):
        if showAll:
            print("This car is a %s %s from %s,it is %s and has %s kms" %(self.make,self.model,self.year,self.condition,self.kms))
        else:
            print("This car is a %s %s from %s" %(self.make,self.model,self.year))
            
whip = car('Ford',"Fusion",2022,'New',10)
whip.display(False)


## static and class methods
class Person(object):
    population=50
    def __init__(self,name,age):
        self.name = name
        self.age = age
   
    # it means we can call it any instance of a class
    @classmethod
    def getPopulation(cls):
        return cls.population
    @staticmethod
    def isAdult(age):
        return age>=18
    
    def display(self):
        print(self.name, 'is', self.age, 'years old')
        
newPersion = Person('chahit',18)
print(Person.isAdult(20))
print(Person.getPopulation())
print(Person.display(Person('chahit',18)))


### map() function
# this si general way we defiine below without map function
li = [1,2,3,4,5,6,7,8,9,10] 

def func(x):
    return x**x

newList = []
for x in li:
    newList.append(func(x))
    
print(newList)

#with map function

li = [1,2,3,4,5,6,7,8,9,10]

def func(x):
    return x**x
#always we can define map function with in the list and inthat we pass function perameter,define list
#then it will performthe given functional operation on define list
print(list(map(func,li)))   ## 1 type
# this is equalent to map function()
print([func(x) for x in li])  ## 2 type
# here added one more condition
print([func(x) for x in li if x%2==0]) # it is given only which values dividid by 2
        

### filter() function
def add7(x):
    return x+7

def isOdd(x):
    return x%2 != 0

a = [1,2,3,4,5,6,7]
b = list(filter(isOdd,a))
print(b)

c = list(map(add7,b)) # 1way
print(c)  
  # or#
c = list(map(add7,list(filter(isOdd,a)))) # 2 way
print(c)

# =============================================================================
# def isCheck(x):
#     return f'hat'+'%'
# 
# a = ['hat','had','hatter',"hamer",'hator']
# b = list(filter(isCheck,a))
# print(b)
# =============================================================================
### LAMDA()
# with out lamda()
def func(x):
    return x+7

print(func(2))

# with lamda()
# only one expression is enough with lamda()

func = lambda x: x+7
print(func(5)) 

#one more way
def func(x):
    func2 = lambda x:x+7
    return func2(x) +85

print(func(2))    

# here we can use optional perameter also
def func(x):
    func2 = lambda x:x+7
    return func2(x) +85

print(func(5))
#without optional perameter
func3 = lambda x,y:x+y
print(func3(5,5))

#with optional perameter
func3 = lambda x=5,y=4:x+y
print(func3())


func3 = lambda x,y=4:x+y
print(func3(5))

func3 = lambda x,y=4:x+y
print(func3(5,6))

# using map(), filter() along with lambda

a = [1,2,3,4,5,6,7,8,9,10]
new = list(map(lambda x:x+5,a))
print(new)

new1 = list(filter(lambda x: x%2 != 0,a))
print(new1)

## counter
import collections
from collections import Counter

c = Counter('pratyusha')
print(c)
c = Counter(['a','a','b','c','c'])
print(c)
c = Counter({'a':1,'b':2})
print(c)
c = Counter(cats =4,dogs =7)
print(c)
print(c['cats'])
# it prints how many number values are there like cats =4, dogs =7
# it adds to the list cats 4 times,dogs 7 times
print(list(c.elements()))
#most common - it gives most reapeted or higher counts values 

print(c.most_common(1)) # here 1 is how may values to show

#subtract the values from counter define values using list
c= Counter(a=4,b=2,c=0,d=-2)
d = ['a','b','b','c','c','d','d']
c.subtract(d)
print(c)

## update -it adds the counts to the counter list
c= Counter(a=4,b=2,c=0,d=-2)
d = ['a','b','b','c','c','d','d']
print(c)
c.update(d)
print(c)
#clear -it's clears the counters list
c.clear()
print(c)

#addition, subtraction, unioin,intersection

c = Counter(a=4,b=2,c=0,d =-2)
d =Counter(['a','b','b','c'])

print("C+D : ",c+d)
print("C-D : ",c-d)
print("C & D : ",c&d) #intersection- given common elements
print('C | D',c|d) #uinin -given max count elements

