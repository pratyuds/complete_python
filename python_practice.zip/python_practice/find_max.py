# -*- coding: utf-8 -*-
"""
Created on Sun Jan 30 09:25:23 2022

@author: praty
"""

def find_max(numbers):
    max = numbers[0]
    for number in numbers:
        if number>max:
            max = number
            
    return max